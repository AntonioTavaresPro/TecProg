import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//-----------------------------------------------------------------------------------------------

class Cliente {

    private String nome;
    private int idade;
    private String sexo;

    public Cliente (String nome, int idade, String sexo) {
        
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
    }

    public String getResumo () {

        return "Nome: " + nome + "\nIdade: " + idade + "\nSexo: " + sexo;
    }
}
//-----------------------------------------------------------------------------------------------

public class CadastroForm extends JFrame {

    private JTextField txtNome;
    private JSpinner spnIdade;
    private JRadioButton rbMasculino, rbFeminino;
    private JButton btnEnviar;
    private JLabel lblResumo;

    public CadastroForm () {

        setTitle ("Cadastro de Cliente");
        setSize (300, 250);
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setLayout (new GridLayout (6, 1, 5, 5));

        add (new JLabel ("Nome:"));
        txtNome = new JTextField ();
        add (txtNome);

        add (new JLabel ("Idade:"));
        spnIdade = new JSpinner (new SpinnerNumberModel (18, 0, 120, 1));
        add (spnIdade);

        add (new JLabel ("Sexo:"));
        JPanel painelSexo = new JPanel ();
        rbMasculino = new JRadioButton ("Masculino");
        rbFeminino = new JRadioButton ("Feminino");
        ButtonGroup grupo = new ButtonGroup ();
        grupo.add (rbMasculino);
        grupo.add (rbFeminino);
        painelSexo.add (rbMasculino);
        painelSexo.add (rbFeminino);
        add (painelSexo);

        btnEnviar = new JButton ("Enviar");
        add (btnEnviar);

        lblResumo = new JLabel ("");
        add (lblResumo);

        btnEnviar.addActionListener (new ActionListener () {

            public void actionPerformed (ActionEvent e) {

                enviar ();
            }
        });

        setLocationRelativeTo (null);
        setVisible (true);
    }
//-----------------------------------------------------------------------------------------------

    private void enviar () {

        String nome = txtNome.getText().trim();
        int idade = (int) spnIdade.getValue();
        String sexo = "";

        if (rbMasculino.isSelected ()) {

            sexo = "Masculino";
        } 
        else if (rbFeminino.isSelected ()) {

            sexo = "Feminino";
        }

        if (nome.equals ("") || sexo.equals ("")) {

            JOptionPane.showMessageDialog (this, "Preencha todos os campos!");
            return;
        }

        Cliente c = new Cliente (nome, idade, sexo);
        lblResumo.setText ("<html>" + c.getResumo ().replaceAll ("\n", "<br>") + "</html>");
    }
//-----------------------------------------------------------------------------------------------

    public static void main (String[] args) {

        SwingUtilities.invokeLater (() -> new CadastroForm ());
    }
}
//-----------------------------------------------------------------------------------------------
