import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//-----------------------------------------------------------------------------------------------

class Usuario {

    private String tema;
    private boolean notificacoes;
    private int volume;

    public void setTema (String tema) {

        this.tema = tema;
    }

    public void setNotificacoes (boolean notificacoes) {

        this.notificacoes = notificacoes;
    }

    public void setVolume (int volume) {

        this.volume = volume;
    }

    public String getTema () {

        return tema;
    }

    public String getResumo () {

        String status = notificacoes ? "Ativadas" : "Desativadas";
        return "Tema: " + tema + "\nNotificações: " + status + "\nVolume: " + volume;
    }
}
//-----------------------------------------------------------------------------------------------

public class PreferenciasUsuario extends JFrame {

    private JComboBox<String> comboTema;
    private JCheckBox chkNotificacoes;
    private JSlider sliderVolume;
    private JButton btnSalvar;
    private JTextArea txtResumo;
    private Usuario usuario = new Usuario ();

    public PreferenciasUsuario () {

        setTitle ("Preferências do Usuário");
        setSize (350, 300);
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        setLayout (new GridLayout (6, 1, 5, 5));

        add (new JLabel ("Tema:"));
        comboTema = new JComboBox<> (new String [] {"Claro", "Escuro"});
        add (comboTema);

        chkNotificacoes = new JCheckBox ("Ativar Notificações");
        add (chkNotificacoes);

        add (new JLabel ("Volume:"));
        sliderVolume = new JSlider (0, 100, 50);
        sliderVolume.setPaintTicks (true);
        sliderVolume.setPaintLabels (true);
        sliderVolume.setMajorTickSpacing (25);
        add (sliderVolume);

        btnSalvar = new JButton ("Salvar");
        add (btnSalvar);

        txtResumo = new JTextArea ();
        txtResumo.setEditable (false);
        add (new JScrollPane (txtResumo));

        btnSalvar.addActionListener (new ActionListener () {

            public void actionPerformed (ActionEvent e) {

                salvar ();
            }
        });

        setLocationRelativeTo (null);
        setVisible (true);
    }
//-----------------------------------------------------------------------------------------------

    private void salvar () {

        String temaEscolhido = (String) comboTema.getSelectedItem ();
        usuario.setTema (temaEscolhido);
        usuario.setNotificacoes (chkNotificacoes.isSelected ());
        usuario.setVolume (sliderVolume.getValue ());

        aplicarTema (temaEscolhido);
        txtResumo.setText (usuario.getResumo ());
    }
//-----------------------------------------------------------------------------------------------

    private void aplicarTema (String tema) {

        if (tema == "Escuro") {

            getContentPane ().setBackground (Color.DARK_GRAY);
            txtResumo.setBackground (Color.GRAY);
            txtResumo.setForeground (Color.WHITE);
        }
        
        else {

            getContentPane () .setBackground (Color.WHITE);
            txtResumo.setBackground (Color.WHITE);
            txtResumo.setForeground (Color.BLACK);
        }
    }
//-----------------------------------------------------------------------------------------------

    public static void main (String [] args) {

        SwingUtilities.invokeLater (() -> new PreferenciasUsuario ());
    }
}
//-----------------------------------------------------------------------------------------------
