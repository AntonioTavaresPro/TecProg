public class Cliente {

    private String nome;
    private String email;
    private int idade;
    private String telefone;
    private String cpf;

    public Cliente(String nome, String email, int idade, String telefone, String cpf) {
        this.nome = nome;
        this.email = email;
        this.idade = idade;
        this.telefone = telefone;
        this.cpf = cpf;
    }

    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public int getIdade() { return idade; }
    public String getTelefone() { return telefone; }
    public String getCpf() { return cpf; }

    @Override
    public String toString() {
        return "Nome: " + nome + " | Idade: " + idade + " | CPF: " + cpf +
               " | Telefone: " + telefone + " | Email: " + email;
    }
}