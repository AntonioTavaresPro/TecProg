public class Funcionario {

    private String nome;
    private String cargo;
    private int idade;
    private double salario;
    private String cpf;

    public Funcionario(String nome, String cargo, int idade, double salario, String cpf) {
        this.nome = nome;
        this.cargo = cargo;
        this.idade = idade;
        this.salario = salario;
        this.cpf = cpf;
    }

    public String getNome() { return nome; }
    public String getCargo() { return cargo; }
    public int getIdade() { return idade; }
    public double getSalario() { return salario; }
    public String getCpf() { return cpf; }

    @Override
    public String toString() {
        return "Nome: " + nome + " | Cargo: " + cargo + " | Idade: " + idade +
               " | CPF: " + cpf + " | Salário: R$ " + salario;
    }
}