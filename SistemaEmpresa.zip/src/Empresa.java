public class Empresa {

    private Cliente[] clientes = new Cliente[5];
    private Funcionario[] funcionarios = new Funcionario[10];
    private int totalClientes = 0;
    private int totalFuncionarios = 0;

    public void adicionarCliente(String nome, String email, int idade, String telefone, String cpf) {
        if (totalClientes < clientes.length) {
            clientes[totalClientes++] = new Cliente(nome, email, idade, telefone, cpf);
        } else {
            System.out.println("Limite de clientes atingido!");
        }
    }

    public String exibirClientes() {
        StringBuilder sb = new StringBuilder("=== Clientes Cadastrados ===\n");
        for (int i = 0; i < totalClientes; i++) {
            sb.append(clientes[i].toString()).append("\n");
        }
        return sb.toString();
    }

    public void adicionarFuncionario(String nome, String cargo, int idade, double salario, String cpf) {
        if (totalFuncionarios < funcionarios.length) {
            funcionarios[totalFuncionarios++] = new Funcionario(nome, cargo, idade, salario, cpf);
        } else {
            System.out.println("Limite de funcionários atingido!");
        }
    }

    public String exibirFuncionarios() {
        StringBuilder sb = new StringBuilder("=== Funcionários ===\n");
        for (int i = 0; i < totalFuncionarios; i++) {
            sb.append(funcionarios[i].toString()).append("\n");
        }
        return sb.toString();
    }

    public double calcularFolhaSalarial() {
        double total = 0;
        for (int i = 0; i < totalFuncionarios; i++) {
            total += funcionarios[i].getSalario();
        }
        return total;
    }

    public double calcularMediaSalarial() {
        if (totalFuncionarios == 0) return 0;
        Calculadora calc = new Calculadora();
        double soma = 0;
        for (int i = 0; i < totalFuncionarios; i++) {
            soma = calc.somar(soma, funcionarios[i].getSalario());
        }
        return soma / totalFuncionarios;
    }

    public String exibirMediaSalarial() {
        return String.format("Média Salarial: R$ %.2f", calcularMediaSalarial());
    }
}