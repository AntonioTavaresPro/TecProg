import java.awt.*;
import javax.swing.*;

public class MainGUI extends JFrame {

    private Empresa empresa = new Empresa();
    private JTextArea areaTexto;

    public MainGUI() {
        setTitle("🌿 Sistema Empresarial - Gestão de Clientes e Funcionários");
        setSize(700, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(240, 248, 255));

        JLabel titulo = new JLabel("🌟 EMPRESA UNIVERSAL - SISTEMA DE GESTÃO 🌟", SwingConstants.CENTER);
        titulo.setFont(new Font("Serif", Font.BOLD, 18));
        titulo.setForeground(new Color(0, 70, 120));
        add(titulo, BorderLayout.NORTH);

        areaTexto = new JTextArea();
        areaTexto.setEditable(false);
        areaTexto.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(areaTexto), BorderLayout.CENTER);

        JPanel botoes = new JPanel(new GridLayout(3, 2, 10, 10));
        botoes.setBackground(new Color(240, 248, 255));

        JButton btnAddCliente = new JButton("➕ Adicionar Cliente");
        JButton btnVerClientes = new JButton("👥 Exibir Clientes");
        JButton btnAddFuncionario = new JButton("➕ Adicionar Funcionário");
        JButton btnVerFuncionarios = new JButton("💼 Exibir Funcionários");
        JButton btnFolha = new JButton("📄 Folha Salarial");
        JButton btnMedia = new JButton("📊 Média Salarial");

        botoes.add(btnAddCliente);
        botoes.add(btnVerClientes);
        botoes.add(btnAddFuncionario);
        botoes.add(btnVerFuncionarios);
        botoes.add(btnFolha);
        botoes.add(btnMedia);

        add(botoes, BorderLayout.SOUTH);

        btnAddCliente.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog("Nome do cliente:");
            String email = JOptionPane.showInputDialog("Email do cliente:");
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade do cliente:"));
            String telefone = JOptionPane.showInputDialog("Telefone:");
            String cpf = JOptionPane.showInputDialog("CPF:");
            empresa.adicionarCliente(nome, email, idade, telefone, cpf);
            areaTexto.setText("✅ Cliente adicionado com sucesso!");
        });

        btnVerClientes.addActionListener(e -> areaTexto.setText(empresa.exibirClientes()));

        btnAddFuncionario.addActionListener(e -> {
            String nome = JOptionPane.showInputDialog("Nome do funcionário:");
            String cargo = JOptionPane.showInputDialog("Cargo:");
            int idade = Integer.parseInt(JOptionPane.showInputDialog("Idade:"));
            double salario = Double.parseDouble(JOptionPane.showInputDialog("Salário:"));
            String cpf = JOptionPane.showInputDialog("CPF:");
            empresa.adicionarFuncionario(nome, cargo, idade, salario, cpf);
            areaTexto.setText("✅ Funcionário adicionado com sucesso!");
        });

        btnVerFuncionarios.addActionListener(e -> areaTexto.setText(empresa.exibirFuncionarios()));

        btnFolha.addActionListener(e -> {
            double total = empresa.calcularFolhaSalarial();
            areaTexto.setText(String.format("💰 Total da folha salarial: R$ %.2f", total));
        });

        btnMedia.addActionListener(e -> areaTexto.setText(empresa.exibirMediaSalarial()));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainGUI().setVisible(true));
    }
}